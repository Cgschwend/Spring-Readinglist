create function "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) returns boolean
STABLE
LANGUAGE SQL
AS $$
select ($1, ($1 + $2)) overlaps ($3, $4)
$$;
